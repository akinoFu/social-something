module.exports = [
  {
    id: "post1",
    imageUrl: "https://i.imgur.com/JnE2HOP.png",
    description: "Where's the c-4? It's in the shed. Speak English! Where's the c-4? It's in the shed. In the shed? It's in the shed? It's in the shed. It's in the shed",
    liked: false,
    totalLikes: 100,
    totalComments: 10,

    user: {
      id: "user1",
      username: "AJ"
    },
    comments: [
      {
        user: {
          id: "user5",
          username: "John"
        },
        text: "It's in the shed.",
        id: "comment1"
      },
      {
        user: {
          id: "user1",
          username: "AJ"
        },
        text: " Man, life's looking pretty good from right here.",
        id: "comment2"
      },
      {
        user: {
          id: "user2",
          username: "Gordon"
        },
        text: "We're takers, gents. That's what we do for a living. We take.",
        id: "comment3"
      },
      {
        user: {
          id: "user5",
          username: "John"
        },
        text: "It's in the shed.",
        id: "comment4"
      },
      {
        user: {
          id: "user1",
          username: "AJ"
        },
        text: " Man, life's looking pretty good from right here.",
        id: "comment5"
      },
      {
        user: {
          id: "user2",
          username: "Gordon"
        },
        text: "We're takers, gents. That's what we do for a living. We take.",
        id: "comment6"
      },
      {
        user: {
          id: "user5",
          username: "John"
        },
        text: "It's in the shed.",
        id: "comment7"
      },
      {
        user: {
          id: "user1",
          username: "AJ"
        },
        text: " Man, life's looking pretty good from right here.",
        id: "comment8"
      },
      {
        user: {
          id: "user2",
          username: "Gordon"
        },
        text: "We're takers, gents. That's what we do for a living. We take.",
        id: "comment9"
      },
      {
        user: {
          id: "user5",
          username: "John"
        },
        text: "It's in the shed.",
        id: "comment10"
      },
      {
        user: {
          id: "user1",
          username: "AJ"
        },
        text: " Man, life's looking pretty good from right here.",
        id: "comment11"
      },
      {
        user: {
          id: "user2",
          username: "Gordon"
        },
        text: "We're takers, gents. That's what we do for a living. We take.",
        id: "comment12"
      }
    ]
  },
  {
    id: "post3",
    imageUrl: "https://i.imgur.com/aVqLAG7.png",
    description: "It's in the shed",
    liked: true,
    totalLikes: 200,
    totalComments: 20,

    user: {
      id: "user2",
      username: "Gordon"
    },
    comments: [
      {
        user: {
          id: "user5",
          username: "John"
        },
        text: "It's in the shed.",
        id: "comment13"
      },
      {
        user: {
          id: "user1",
          username: "AJ"
        },
        text: " Man, life's looking pretty good from right here.",
        id: "comment14"
      },
      {
        user: {
          id: "user2",
          username: "Gordon"
        },
        text: "We're takers, gents. That's what we do for a living. We take. Gordon Jennings: We're takers, gents. That's what we do for a living. We take.",
        id: "comment15"
      }
    ]
  },
  {
    id: "post2",
    imageUrl: "https://i.imgur.com/JnE2HOP.png",
    description: "Where's the c-4? It's in the shed. Speak English! Where's the c-4? It's in the shed. In the shed? It's in the shed? It's in the shed. It's in the shed",
    liked: true,
    totalLikes: 300,
    totalComments: 30,

    user: {
      id: "user3",
      username: "Ghost"
    },
    comments: [
      {
        user: {
          id: "user5",
          username: "John"
        },
        text: "It's in the shed.",
        id: "comment16"
      },
      {
        user: {
          id: "user1",
          username: "AJ"
        },
        text: " Man, life's looking pretty good from right here.",
        id: "comment17"
      },
      {
        user: {
          id: "user2",
          username: "Gordon"
        },
        text: "We're takers, gents. That's what we do for a living. We take. Gordon Jennings: We're takers, gents. That's what we do for a living. We take.",
        id: "comment18"
      }
    ]
  },
  {
    id: "post4",
    imageUrl: "https://i.imgur.com/aVqLAG7.png",
    description: "It's in the shed",
    liked: true,
    totalLikes: 400,
    totalComments: 40,

    user: {
      id: "user4",
      username: "Jesse"
    },
    comments: [
      {
        user: {
          id: "user5",
          username: "John"
        },
        text: "It's in the shed.",
        id: "comment19"
      },
      {
        user: {
          id: "user1",
          username: "AJ"
        },
        text: " Man, life's looking pretty good from right here.",
        id: "comment20"
      },
      {
        user: {
          id: "user2",
          username: "Gordon"
        },
        text: "We're takers, gents. That's what we do for a living. We take. Gordon Jennings: We're takers, gents. That's what we do for a living. We take.",
        id: "comment21"
      }
    ]
  }
]
