const data = require('./fakeData')

async function getPosts() {
  return data
}
exports.getPosts = getPosts